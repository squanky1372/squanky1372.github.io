# Custom google map with json and swiper.

Here is the demo link - https://codepen.io/hpi1hpi/pen/eoNpzX

Add google map with custom color and data from json with slider. Change google map API key after download project 

<script src="https://maps.googleapis.com/maps/api/js?key="Add API KEY"&callback=initMap" async defer></script>



